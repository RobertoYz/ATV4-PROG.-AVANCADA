package org.example;

public interface PaymentStrategy {
    public void processPayment(double amount);
}
